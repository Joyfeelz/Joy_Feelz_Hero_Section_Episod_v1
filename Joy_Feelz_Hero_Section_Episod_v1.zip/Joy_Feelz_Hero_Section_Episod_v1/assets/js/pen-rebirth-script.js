function toggleMenu_1() {
    document.getElementById('pen-rebirth-container-later').style.display="block";
    document.getElementById('hamburger_1').style.display="none";
    document.getElementById('hamburger_2').style.display="flex";
} 
function toggleMenu_2() {
    document.getElementById('pen-rebirth-container-later').style.display="none";
    document.getElementById('hamburger_2').style.display="none";
    document.getElementById('hamburger_1').style.display="flex";
} 
